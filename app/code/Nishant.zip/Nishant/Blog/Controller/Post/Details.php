<?php

declare(strict_types=1);

namespace Nishant\Blog\Controller\Post;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;

class Details implements HttpGetActionInterface
{
    public function __construct(
        private Session $session,
        private RequestInterface $request,
        private PageFactory $pageFactory,
    ) {}
    public function execute(): Page
    {
        // echo "<pre>";
        // var_dump($this->session->getData());
        // var_dump($this->request->getParams());
        // die("This is the details action");
        return $this->pageFactory->create();
    }
}
