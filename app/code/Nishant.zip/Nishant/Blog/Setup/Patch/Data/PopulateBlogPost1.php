<?php declare (strict_types = 1);

namespace Nishant\Blog\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Nishant\Blog\Api\PostRepositoryInterface;
use Nishant\Blog\Model\PostFactory;

class PopulateBlogPost1 implements DataPatchInterface
{
    public function __construct(
        private PostFactory $postFactory,
        private PostRepositoryInterface $postRepository,
        private ModuleDataSetupInterface $moduleData,
    ) {}
    public function getAliases(): array
    {
        return [];
    }
    public static function getDependencies(): array
    {
        return [];
    }
    public function apply()
    {
        $this->moduleData->startSetup();
        $post = $this->postFactory->create();
        $post->setData(['title' => 'My movie review', 'content' => 'I give this movie -5 out of 5']);
        $this->postRepository->save($post);
        $this->moduleData->endSetup();

    }
}
