<?php declare (strict_types = 1);

namespace Nishant\Blog\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Nishant\Blog\Api\PostRepositoryInterface;
use Nishant\Blog\Model\PostFactory;

class PopulateBlogPost implements DataPatchInterface
{
    public function __construct(
        private ModuleDataSetupInterface $moduleDataSetup,
        private PostFactory $postFactory,
        private PostRepositoryInterface $postRepository,

    ) {}
    public function apply()
    {
        $this->moduleDataSetup->startSetup();

        $post = $this->postFactory->create();
        $post->setData(['title' => 'Today is Sunny Day', 'content' => 'The weather has been great all week.']);
        $this->postRepository->save($post);

        $this->moduleDataSetup->endSetup();
    }
    public function getAliases(): array
    {
        return [];
    }
    public static function getDependencies(): array
    {
        return [];
    }
}
